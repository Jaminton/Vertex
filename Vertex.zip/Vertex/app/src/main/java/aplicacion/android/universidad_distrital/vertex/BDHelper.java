package aplicacion.android.universidad_distrital.vertex;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

/**
 * Created by Android on 06/02/2018.
 */

public class BDHelper extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION= 1;
    public static final String DATABASE_NAME = "BDVERTEX.db";




    public static abstract class DatosTabla implements BaseColumns {

        public static final String NOMBRE_TABLA = "Formulario";
        public static final String CEDULA_ID   =  "Cedula";
        public static final String COLUMNA_NOMBRESV= "nombrev";
        public static final String COLUMNA_NOMENCLATURA = "nomenclatura";
        public static final String COLUMNA_LAT= "lat";
        public static final String COLUMNA_LONG= "long";
        public static final String COLUMNA_ALTURA= "altura";
        public static final String COLUMNA_ENTIDAD= "entidad";
        public static final String COLUMNA_TIPOVERTICE= "tipovertice";
        public static final String COLUMNA_DATUM= "datum";
        public static final String COLUMNA_DEPARTAMENTO= "departamento";
        public static final String COLUMNA_MUNICIPIO= "municipio";
        public static final String COLUMNA_SITIO= "sitio";
        public static final String COLUMNA_ESTADOVERTICE= "estadovertice";
        public static final String COLUMNA_DESCRIBIO= "describio";
        public static final String COLUMNA_FECHA= "fecha";
        public static final String COLUMNA_HORA= "hora";



        private static final String SQL_DELETE_ENTRIES =
                "DROP TABLE IF EXISTS" + DatosTabla.NOMBRE_TABLA;
        private static final String TEXT_TYPE = "TEXT";
        private static final String COMMA_SEP = ",";
        private static final String CREAR_TABLA1 =
                "CREATE TABLA" + DatosTabla.NOMBRE_TABLA + "(" +
                        DatosTabla.CEDULA_ID + "integer primary key," +
                        DatosTabla.COLUMNA_NOMBRESV + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_NOMENCLATURA + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_LAT + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_LONG + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_ALTURA + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_ENTIDAD + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_TIPOVERTICE + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_DATUM + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_DEPARTAMENTO + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_MUNICIPIO + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_SITIO + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_ESTADOVERTICE + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_DESCRIBIO + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_FECHA + TEXT_TYPE + COMMA_SEP +
                        DatosTabla.COLUMNA_HORA + TEXT_TYPE + ")";
    }


    public BDHelper(Context context) {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
                db.execSQL(DatosTabla.CREAR_TABLA1 );

   }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(DatosTabla.SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
