package aplicacion.android.universidad_distrital.vertex;

import android.provider.BaseColumns;

/**
 * Created by Android on 06/02/2018.
 */

//public static abstract class DatosTabla implements BaseColumns {
//
//    public static final String NOMBRE_TABLA = "Formulario";
//    public static final String COLUMNA_ID   =  "id";
//    public static final String COLUMNA_NOMBRES= "nombre";
//    public static final String COLUMNA_NOMENCLATURA = "nomenclatura";
//    public static final String COLUMNA_LAT= "lat";
//    public static final String COLUMNA_LONG= "long";
//    public static final String COLUMNA_ALTURA= "altura";
//    public static final String COLUMNA_ENTIDAD= "entidad";
//    public static final String COLUMNA_TIPOVERTICE= "tipovertice";
//    public static final String COLUMNA_DATUM= "datum";
//    public static final String COLUMNA_DEPARTAMENTO= "departamento";
//    public static final String COLUMNA_MUNICIPIO= "municipio";
//    public static final String COLUMNA_SITIO= "sitio";
//    public static final String COLUMNA_ESTADOVERTICE= "estadovertice";
//    public static final String COLUMNA_DESCRIBIO= "describio";
//    public static final String COLUMNA_FECHA= "fecha";
//    public static final String COLUMNA_HORA= "hora";
//}
