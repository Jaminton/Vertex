package aplicacion.android.universidad_distrital.vertex;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Formulario extends AppCompatActivity {







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        Integer id=0;
        Button enviar;
        final Spinner opciones,opestado,municipio,departamento;
        final EditText cedula,Formulario,nombrev,nomenclatura,lat,log,altura,entidad,tipovertice,datum,sitio,estadovertice,describio,hora,fecha;
        final Integer ide = id++;



        opciones        = (Spinner)findViewById(R.id.sp01);
        opestado        = (Spinner)findViewById(R.id.sp02);
        municipio       = (Spinner)findViewById(R.id.sp03);
        departamento    = (Spinner)findViewById(R.id.sp04);
        cedula          = (EditText)findViewById(R.id.cedula1);



        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.opciones, android.R.layout.simple_spinner_item );
        opciones.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(this, R.array.opestado, android.R.layout.simple_spinner_item );
        opestado.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(this, R.array.municipio, android.R.layout.simple_spinner_item );
        municipio.setAdapter(adapter3);

        ArrayAdapter<CharSequence> adapter4 = ArrayAdapter.createFromResource(this, R.array.departamento, android.R.layout.simple_spinner_item );
        departamento.setAdapter(adapter4);





        enviar =(Button)findViewById(R.id.enviar1);

        final BDHelper  bdhelper = new BDHelper(getApplicationContext());

        enviar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {


                SQLiteDatabase db = bdhelper.getWritableDatabase();
                ContentValues valores = new ContentValues();
                valores.put(BDHelper.DatosTabla.CEDULA_ID,opciones.getText().toString());


            }
        });
    }
}
