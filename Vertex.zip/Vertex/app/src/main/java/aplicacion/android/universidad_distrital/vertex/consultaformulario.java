package aplicacion.android.universidad_distrital.vertex;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class consultaformulario extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultaformulario);
    }
}
